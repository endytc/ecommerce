<div id="sidebarFashion">
    <ul>
        <li>
    <table class="myOtherTable">
        <tr>
            <th>Berita</th>
        </tr>
        <tr>
        <td>
            <li><a href="<? echo app_base_url('pageadmin/berita/add')?>">Tambah</a> </li>
            <li> <a href="<? echo app_base_url('pageadmin/berita/index')?>">List</a> </li>
        </td>
        </tr>
    </table>
            </li>
    </ul>
</div>