<div id="sidebarFashion">
    <ul>
        <li>
    <table class="myOtherTable">
        <tr>
            <th>Sub Kriteria</th>
        </tr>
        <tr>
        <td>
            <li><a href="<? echo app_base_url('pageadmin/sub_kriteria/add')?>">Tambah</a> </li>
            <li> <a href="<? echo app_base_url('pageadmin/sub_kriteria/index')?>">List</a> </li>
            <li> <a href="<? echo app_base_url('pageadmin/kategori/index')?>">Kategori</a> </li>
        </td>
        </tr>
    </table>
            </li>
    </ul>
</div>