<?php
session_unset();
redirect();
?>
