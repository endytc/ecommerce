
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Website E-commerce</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <link href="../assets/admin.css" rel="stylesheet" type="text/css" media="screen" />
    <center>
        <br> <h2>Pengelolaan Kuesioner</h2> </br>
        <form id="proses" action="">
            <table>
                
                <tr>
                    <td align="left">
                        
                        <a href="https://docs.google.com/forms/d/1-R1RkmS0qpjTd7HpXy7-rPyelH6aoDDvE85CAoHmtQ0/viewform" target="_blank" align="left">Google Docs (Kuesioner Pembeli)</a>&nbsp;&nbsp;||
                        <a href="https://docs.google.com/forms/d/1T7OszNuXpEawkdBXJSe2I_44QgNMInVT3Do2FPDNe78/viewform" target="_blank" align="left">Google Docs (Kuesioner Member)</a>&nbsp;&nbsp;
                    </td>

                </tr>
            </table>
        </form>
    </center>
</head

