<div id="sidebarFashion">
    <ul>
        <li>
            <table class="myOtherTable">
                <tr>
                    <th>Main Menu</th>
                </tr>
                <tr>
                    <td>
                        <li class='last'><a href='<?php echo app_base_url('pageadmin/Kuisioner') ?>'><span>Pengelolaan Kuisioner</span></a></li>
                        <li class='last'><a href='<?php echo app_base_url('pageadmin/ListAdmin') ?>'><span>Pengelolaan Admin</span></a></li>
                    </td>
                </tr>
            </table>
        </li>
    </ul>
</div>