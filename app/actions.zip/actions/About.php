
<html>
    <head>
        <?php include 'app/views/head.php'; ?>
        <title>www.W2Shop.co.id</title>
        
    </head>
    <body>
<tr>
    <td width="100%" align="center">
        <table align="center" border="0" width="950" cellspacing="0" cellpadding="0">

            <tr><td width="100%" valign="bottom" height="20" class="infokecil" style="font-size: 11"> </td></tr>
            <tr><td width="100%">
                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="705" valign="top">
                                <table border="0" width="95%" cellspacing="1" cellpadding="2">
                                    <tr><td width="100%" valign="bottom" height="45" class="judulberita_deskripsi" style="font-size: 20;color: #cc6600">Tentang W2Shop</td></tr>
                                    <tr><td width="100%" class="deskripsi"><font class="infokecil"></font></td></tr>

                                    <tr><td width="100%" class="deskripsi">
                                            <p>
                                            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;W2Shop.co.id adalah salah satu website e-commerce yang menjual berbagai produk dengan kategori seperti fashion pria dan wanita, properti dan elektronik.Website ini didirikan dengan agar dapat memberikan kenyamanan dan kemudahan berbelanja secara online.Jika ingin menjual produk diwebsite ini, maka user bisa mendaftar menjadi member.</p>
                                           

                                            <ol> </ol>
                                            <p>&nbsp;</p></p>
                                        </td></tr>

                                    <tr><td width="100%">
                                            <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                                <tr>
                                                </tr>

                                            </table>
                                        </td></tr>
                                    <tr><td width="100%" height="20"></td></tr>
                            </td></tr>
                        <tr><td width="100%" height="20"></td></tr>
                        <tr><td width="100%" height="20"></td></tr>
                        <tr><td width="100%"></td></tr>

                    </table>
                </td>
                
                            </tr>

                        </table>

                </td>
            </tr>

            <tr><td width="100%" align="center" height="50"></td></tr>
            <tr><td width="100%" align="center"></td></tr>
        </table>
    </td>
</tr>

</table>

<tr><td width="100%" align="center" height="30"></td></tr>

<!-- #C0A172 -->

<tr><td width="100%" align="center" height="40"></td></tr>
</table>

</td>
</tr>
<tr><td width="100%"></td></tr>
</table>
</td>
</tr>
</body>
</html>
