<html>
    <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <title>Website E-commerce</title>
            <meta name="keywords" content="" />
            <meta name="description" content="" />
            <link href="default.css" rel="stylesheet" type="text/css" media="screen" />
            <?php include "Header.php"; ?>

           
        </head>

        <!-- Codes by HTML.am -->
<!-- Start Styles. Move the 'style' tags and everything between them to between the 'head' tags -->


<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
