
<div id="sidebarFashion">
    <ul>
        <li>
            <table class="myOtherTable">
                <tr>
                    <th>Menu</th>
                </tr>
                <tr>
                    <td>
                       <!-- <li><a href='<?php echo app_base_url('pagemember/produk') ?>'><span>Pengelolaan Produk</span></a></li>-->
                        <li><a href='<?php echo app_base_url('pagemember/laporan')?>'><span>Pengelolaan Laporan</span></a></li>
                        
                    </td>
                </tr>
            </table>
        </li>
    </ul>
</div>