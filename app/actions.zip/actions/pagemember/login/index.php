<?php 
$_SESSION['layout']='views/login';
?>
