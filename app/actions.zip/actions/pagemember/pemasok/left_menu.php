<div id="sidebarFashion">
    <ul>
        <li>
    <table class="myOtherTable">
        <tr>
            <th>Supplier</th>
        </tr>
        <tr>
        <td>
            <li><a href="<? echo app_base_url('pagemember/pemasok/add')?>">Tambah</a> </li>
            <li> <a href="<? echo app_base_url('pagemember/pemasok/index')?>">List</a> </li>
        </td>
        </tr>
    </table>
            </li>
    </ul>
</div>