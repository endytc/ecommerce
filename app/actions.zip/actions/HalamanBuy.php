<html>
    <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <title>Website E-commerce</title>
            <meta name="keywords" content="" />
            <meta name="description" content="" />
            <link href="default.css" rel="stylesheet" type="text/css" media="screen" />
            <?php include "Header.php"; ?>
            <?php include "ListMenuKanan.php"; ?>
            

        </head>
    </html>