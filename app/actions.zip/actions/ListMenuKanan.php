<html>
    <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8" />
            <title>Website E-commerce</title>
            <meta name="keywords" content="" />
            <meta name="description" content="" />
            <link href="default.css" rel="stylesheet" type="text/css" media="screen" />
            
            <style type="text/css">
                .myOtherTable { background-color:#FFFFE0;border-collapse:collapse;color:#000;font-size:18px; }
                .myOtherTable th { background-color:#C28C21;color:white;width:50%; }
                .myOtherTable td, .myOtherTable th { padding:5px;border:0; }
                .myOtherTable td { border-bottom:1px dotted #C28C21; }
                .myOtherTable a{padding:0px; background:#FFFFE; color:black}
            </style>
        </head>

        <div id="sidebarFashion">
            <ul>
                <li>
                    <h2>Categories</h2>
                    <ul>
                        <table class="myOtherTable">
                            <tr>
                                <th>Fashion Wanita</th>
                            </tr>
                            <td><li><a href="#">Pakaian</a> </li>
                            <li> <a href="#">Cosmetic</a> </li>
                            <li> <a href="#">tas</a> </li>
                            <li> <a href="#">sepatu</a> </li>
                            <li> <a href="#">aksesoris</a> </li>
                            </td>
                            </tr>
                            <tr>
                                <th>Fashion Pria</th>
                            </tr>
                            <td><li><a href="#">Pakaian</a> </li>
                            <li> <a href="#">Cosmetic</a> </li>
                            <li> <a href="#">tas</a> </li>
                            <li> <a href="#">sepatu</a> </li>
                            <li> <a href="#">aksesoris</a> </li>
                            </td>
                            </tr>

                             <tr>
                                <th>Kamera</th>
                            </tr>
                            <td><li><a href="#">Canon</a> </li>
                            <li> <a href="#">Nikon</a> </li>
                            <li> <a href="#">Digital</a> </li>
                            <li> <a href="#">Polaroid</a> </li>
                            </td>

                            <tr>
                                <th>HP</th>
                            </tr>
                            <td><li><a href="#">Iphone</a> </li>
                            <li> <a href="#">BlackBerry</a> </li>
                            <li> <a href="#">Samsung</a> </li>
                            <li> <a href="#">Nokia</a> </li>
                            <li> <a href="#">Sony</a> </li>
                             </td>
                            <tr>
                                <th>Komputer</th>
                            </tr>
                             <td><li><a href="#">Hardware</a> </li>
                            <li> <a href="#">Software</a> </li>
                            <li> <a href="#">Aksesoris</a> </li>
                             </td>
                            <tr>
                                <th>Laptop</th>
                            </tr>
                            <td><li><a href="#">Apple</a> </li>
                            <li> <a href="#">Thosiba</a> </li>
                            <li> <a href="#">Samsung</a> </li>
                            <li> <a href="#">lenovo</a> </li>
                            <li> <a href="#">Sony vaio</a> </li>
                            <li> <a href="#">Acer</a> </li>
                            <li> <a href="#">Asus</a> </li>
                            <li> <a href="#">Dell</a> </li>
                            <tr>
                                </td>
                                <th>Lainnya</th>
                            </tr>

                             <tr>
                                <th>Rumah</th>
                            </tr>
                            <td><li><a href="#">Ruko</a> </li>
                            <li> <a href="#">Tanah</a> </li>
                            <li> <a href="#">Modern</a> </li>
                            <li> <a href="#">Minimalis</a> </li>
                            <li> <a href="#">Klasik</a> </li>
                            </td>

                            <tr>
                                <th><a href="#">Interior Rumah</a></th>
                            </tr>

                            <tr>
                                <th><a href="#">Furnitur Rumah</a></th>
                            </tr>

                             </td>
                            <tr>
                                <th><a href="#">Kitchen Set</a></th>
                            </tr>

                                <th><a href="#">Lainnya</a></th>
                            </tr>

                        </table>

                </li>
            </ul>
        </div>
<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
